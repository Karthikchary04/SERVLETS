package project_Class_Interface;

import java.util.ArrayList;

import project_Model.LibrarianModel;
import project_Model.AdminModel;
import project_Model.BookModel;
import project_Model.RequestModel;
import project_Model.StudentModel;

public interface Library_Interface 
{
	//admin
	public boolean adminLogin(AdminModel am);
	public ArrayList<LibrarianModel> viewLibrarians();
	public ArrayList<RequestModel> getBooks(String sdate,String edate,RequestModel r);
	
	//librarian
    public boolean librarianLogin(LibrarianModel a);
    public boolean librarianRegister(LibrarianModel a);
    public boolean forgotPassword(LibrarianModel a);
    public boolean addBooksInLibrary(BookModel a);
    public ArrayList<BookModel> viewBooksInLibrary();
    public boolean updateBookQuantiy(BookModel bo);
    public ArrayList<RequestModel> checkBookRequestsFromStudents();
    public boolean issueBookToStudents(RequestModel r,BookModel bo);
    public boolean librarianLogout(LibrarianModel a);
    
    
    //student
    public boolean studentLogin(StudentModel s);
    public boolean studentRegister(StudentModel s);
    public boolean studentForgot(StudentModel s);
    public ArrayList<BookModel> viewBooksInLibrary(BookModel bo);
    public boolean requestBook(RequestModel r);
    public ArrayList<RequestModel> mybooks();
    public boolean returnBook(RequestModel r,BookModel bo);
    public boolean studentLogout(StudentModel s);
}
