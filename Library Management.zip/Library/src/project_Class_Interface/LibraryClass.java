package project_Class_Interface;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import project_Model.LibrarianModel;
import project_Model.AdminModel;
import project_Model.BookModel;
import project_Model.RequestModel;
import project_Model.StudentModel;

public class LibraryClass implements Library_Interface
{   
	RequestModel  r=null;
	int sid=0;
	static Connection con=null;
	public static Connection getConnectionObject()
	{
		try 
		{
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","karthik","Karthik@04");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}
	public boolean adminLogin(AdminModel am) 
	{
		boolean b=false;
		ResultSet rs=null;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from libraryadmin");
			if(rs.next())
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<LibrarianModel> viewLibrarians()
	{
		ArrayList<LibrarianModel> al=new ArrayList<LibrarianModel>();
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from librarians");
			while(rs.next())
			{
				LibrarianModel l=new LibrarianModel();
				l.setFullname(rs.getString(1));
				l.setUsername(rs.getString(2));
				l.setEmail(rs.getString(3));
				al.add(l);
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return al;
	}
	public ArrayList<RequestModel> getBooks(String sdate,String edate,RequestModel r) 
	{
		ArrayList<RequestModel> al=new ArrayList<RequestModel>();
		ResultSet rs=null;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			System.out.println("start date"+sdate);
			System.out.println("end date"+edate);
			rs=st.executeQuery("select * from issuedbooks where issuedate between '"+r.getIssuedate()+"' and '"+r.getReturndate()+"'"); 
			while(rs.next())
			{
				RequestModel r1=new RequestModel();
				r1.setBookid(rs.getInt(1));
				r1.setBookname(rs.getString(2));
				r1.setStudentid(rs.getInt(3));
				r1.setIssuedate(rs.getString(4));
				r1.setReturndate(rs.getString(5));
				al.add(r1);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public boolean librarianLogin(LibrarianModel a) 
    {   
		boolean b=false;
		ResultSet rs=null;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select username,password from libraryadmin where username='"+a.getUsername()+"' and password='"+a.getPassword()+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean librarianRegister(LibrarianModel a) 
	{
		boolean b=false;
		int i=0;
		con=LibraryClass.getConnectionObject();
		try
		{
			PreparedStatement pst=con.prepareStatement("insert into librarians values(?,?,?,?)");
			pst.setString(1,a.getFullname());
			pst.setString(2,a.getUsername());
			pst.setString(3,a.getEmail());
			pst.setString(4,a.getPassword());
			i=pst.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean forgotPassword(LibrarianModel a)
	{
		boolean b=false;
		int i=0;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			i=st.executeUpdate("update librarians set password='"+a.getPassword()+"' where email='"+a.getEmail()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
	    return b;
	}
	public boolean addBooksInLibrary(BookModel bo) 
	{
		boolean b=false;
		int i=0;
		con=LibraryClass.getConnectionObject();
		try
		{
			PreparedStatement pst=con.prepareStatement("insert into librarybooks values(?,?,?,?)");
			pst.setInt(1,bo.getBookid());
			pst.setString(2,bo.getBookname());
			pst.setInt(3,bo.getQuantity());
			pst.setInt(4,bo.getIssued());
			i=pst.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			b=false;
		}
		return b;
	}
	public ArrayList<BookModel> viewBooksInLibrary() 
	{
		ResultSet rs=null;
		ArrayList<BookModel> al=new ArrayList<BookModel>();
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from librarybooks");
			while(rs.next())
			{
				BookModel bo=new BookModel();
				bo.setBookid(Integer.parseInt(rs.getString(1).trim()));
				bo.setBookname(rs.getString(2));
				bo.setQuantity(Integer.parseInt(rs.getString(3).trim()));
				bo.setIssued(Integer.parseInt(rs.getString(4).trim()));
				al.add(bo);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return al;
	}
	public ResultSet updateSupporter(BookModel bo)
	{
		ResultSet rs=null;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select noofbooks from librarybooks where bookid='"+bo.getBookid()+"'");
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return rs;
	}
	public boolean updateBookQuantiy(BookModel bo) 
	{
		boolean b=false;
		int i=0;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			i=st.executeUpdate("update librarybooks set noofbooks='"+bo.getQuantity()+"' where bookid='"+bo.getBookid()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean deleteBook(BookModel bo)
	{
		boolean b=false;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			int i=st.executeUpdate("delete from librarybooks where bookid='"+bo.getBookid()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean librarianLogout(LibrarianModel a) 
	{
		boolean b=false;
		
		return b;
	}
	public boolean studentLogin(StudentModel s) 
	{
		boolean b=false;
		ResultSet rs=null;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select username,password,sid from librarystudent where username='"+s.getUsername()+"' and password='"+s.getPassword()+"'");
			if(rs.next())
			{
				sid=rs.getInt(3);
				r=new RequestModel();
				r.setStudentid(Integer.parseInt(rs.getString(3).trim()));
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean studentRegister(StudentModel s) 
	{
		boolean b=false;
		int i=0;
		con=LibraryClass.getConnectionObject();
		try
		{
			PreparedStatement pst=con.prepareStatement("insert into librarystudent values(?,?,?,?,?)");
			pst.setInt(1,s.getStudentid());
			pst.setString(2,s.getFullname());
			pst.setString(3,s.getUsername());
			pst.setString(4,s.getEmail());
			pst.setString(5,s.getPassword());
			i=pst.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
            System.out.println(e);
		}
		return b;
	}
	public boolean studentForgot(StudentModel s) 
	{
		boolean b=false;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			int i=st.executeUpdate("update librarystudent set password='"+s.getPassword()+"' where email='"+s.getEmail()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<BookModel> viewBooksInLibrary(BookModel bo) 
	{
		ArrayList<BookModel> al =new ArrayList<BookModel>();
		ResultSet rs=null;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select bookid,bookname from librarybooks where bookname='"+bo.getBookname()+"'");
			if(rs.next())
			{
		       BookModel bo1=new BookModel();
		       bo1.setBookid(Integer.parseInt(rs.getString(1).trim()));
		       bo1.setBookname(rs.getString(2));
		       al.add(bo1);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public boolean requestBook(RequestModel r)
	{
		boolean b=false;
		int i=0;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select bookname from librarybooks where bookid='"+r.getBookid()+"'");
			if(rs.next())
			{
				r.setStudentid(sid);
			r.setBookname(rs.getString(1));
			}
			PreparedStatement pst=con.prepareStatement("insert into bookrequest values(?,?,?)");
			pst.setInt(1,r.getBookid());
			pst.setString(2,r.getBookname());
			pst.setInt(3,r.getStudentid());
			i=pst.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
	       System.out.println(e);
		}
		return b;
	}
	public ArrayList<RequestModel> checkBookRequestsFromStudents() 
	{
		ArrayList<RequestModel> al=new ArrayList<RequestModel>();
		ResultSet rs=null;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from bookrequest");
			while(rs.next())
			{
				RequestModel r=new RequestModel();
				r.setBookid(Integer.parseInt(rs.getString(1).trim()));
				r.setBookname(rs.getString(2));
				r.setStudentid(Integer.parseInt(rs.getString(3).trim()));
				al.add(r);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public RequestModel issueBook(RequestModel r)
	{
		ResultSet rs=null;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select bookid,bookname,sid from bookrequest where bookid='"+r.getBookid()+"' and sid='"+r.getStudentid()+"'");
			if(rs.next())
			{
				r.setBookid(Integer.parseInt(rs.getString(1).trim()));
				r.setBookname(rs.getString(2));
				r.setStudentid(Integer.parseInt(rs.getString(3).trim()));
				st.executeUpdate("delete from bookrequest where sid='"+r.getStudentid()+"' and bookid='"+r.getBookid()+"'");
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);
		}
		return r;
	}
	public boolean issueBookToStudents(RequestModel r,BookModel bo) 
	{
		boolean b=false;
		int i=0;
		con=LibraryClass.getConnectionObject();
		try
		{
			PreparedStatement pst=con.prepareStatement("insert into issuedbooks values(?,?,?,?,?)");
			pst.setInt(1,r.getBookid());
			pst.setString(2,r.getBookname());
			pst.setInt(3,r.getStudentid());
			pst.setString(4,r.getIssuedate());
			pst.setString(5,r.getReturndate());
			i=pst.executeUpdate();
			if(i>0)
			{
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select noofbooks,issued from librarybooks where bookid='"+r.getBookid()+"'");
				if(rs.next())
				{
					bo.setQuantity(Integer.parseInt(rs.getString(1)));
					bo.setIssued(Integer.parseInt(rs.getString(2)));
					if(bo.getQuantity()>0)
					{
				       st.executeUpdate("update librarybooks set issued='"+((bo.getIssued())+1)+"',noofbooks='"+((bo.getQuantity())-1)+"' where bookid='"+r.getBookid()+"'");
				       pst=con.prepareStatement("insert into librarystudentbooks values(?,?,?)");
				       pst.setInt(1,r.getStudentid());
				       pst.setString(2,r.getBookname());
				       pst.setString(3,r.getReturndate());
				       int j=pst.executeUpdate();
				       if(j>0)
				       {
					      b=true;	
				       }
					}
				}
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<RequestModel> mybooks() 
	{
		ArrayList<RequestModel> al=new ArrayList<RequestModel>();
		ResultSet rs=null;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from librarystudentbooks where sid='"+r.getStudentid()+"'");
			while(rs.next())
			{
				RequestModel r=new RequestModel();
				r.setBookname(rs.getString(2));
				r.setReturndate(rs.getString(3));
				al.add(r);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public boolean returnBook(RequestModel r,BookModel bo) 
	{
		boolean b=false;
		con=LibraryClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select noofbooks,issued from librarybooks where bookname='"+r.getBookname()+"'");
			if(rs.next())
			{
			  bo.setQuantity(Integer.parseInt(rs.getString(1).trim()));
			  bo.setIssued(Integer.parseInt(rs.getString(2).trim()));
			}
			int j=st.executeUpdate("update librarybooks set noofbooks='"+(bo.getQuantity()+1)+"',issued='"+(bo.getIssued()-1)+"' where bookname='"+r.getBookname()+"'");
			int i=st.executeUpdate("delete from librarystudentbooks where mybooks='"+r.getBookname()+"'");
			if(i>0 && j>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean studentLogout(StudentModel s) 
	{
		// TODO Auto-generated method stub
		return false;
	}
}
