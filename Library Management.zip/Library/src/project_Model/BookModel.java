package project_Model;

public class BookModel
{
    private int bookid,quantity,issued;
    private String bookname;
	public int getBookid() 
	{
		return bookid;
	}
	public void setBookid(int bookid) 
	{
		this.bookid = bookid;
	}
	public int getQuantity() 
	{
		return quantity;
	}
	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}
	public int getIssued() 
	{
		return issued;
	}
	public void setIssued(int issued)
	{
		this.issued = issued;
	}
	public String getBookname() 
	{
		return bookname;
	}
	public void setBookname(String bookname) 
	{
		this.bookname = bookname;
	}
}
