package project_Model;

public class RequestModel 
{
    private int studentid,bookid;
    private String bookname,issuedate,returndate;
	public String getIssuedate() 
	{
		return issuedate;
	}
	public void setIssuedate(String issuedate) 
	{
		this.issuedate = issuedate;
	}
	public String getReturndate()
	{
		return returndate;
	}
	public void setReturndate(String returndate) 
	{
		this.returndate = returndate;
	}
	public int getStudentid() 
	{
		return studentid;
	}
	public void setStudentid(int studentid) 
	{
		this.studentid = studentid;
	}
	public int getBookid() 
	{
		return bookid;
	}
	public void setBookid(int bookid) 
	{
		this.bookid = bookid;
	}
	public String getBookname() 
	{
		return bookname;
	}
	public void setBookname(String bookname) 
	{
		this.bookname = bookname;
	}
}
