package project_controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project_Class_Interface.LibraryClass;
import project_Model.AdminModel;
import project_Model.BookModel;
import project_Model.LibrarianModel;
import project_Model.RequestModel;
import project_Model.StudentModel;
@WebServlet(urlPatterns = {"/adlogin","/viewlibrarians","/getbooks"}) 
public class AdminController extends HttpServlet
{
	 LibraryClass li;
	 public void init() throws ServletException
	 {
		 super.init();
		 li=new LibraryClass();
	 }
	 public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException
	 {
		 String path=req.getServletPath();
    	 PrintWriter out=res.getWriter();
    	 LibrarianModel a=new LibrarianModel();
    	 BookModel bo=new BookModel();
    	 RequestModel r=new RequestModel();
    	 StudentModel s=new StudentModel();
    	 if(path.equals("/viewlibrarians"))
	     {
	    	 ArrayList<LibrarianModel> al=new ArrayList<LibrarianModel>();
	    	 al=li.viewLibrarians();
	    	 out.print("<center><body><table border=1 cellpadding=7><tr><td>Fullname</td><td>Username</td><td>email</td></tr>");
	    	 for(LibrarianModel l: al)
	    	 {
	    		 out.print("<tr><td>"+l.getFullname()+"</td><td>"+l.getUsername()+"</td><td>"+l.getEmail()+"</td></tr>");
	    	 }
	     }
    	 else if(path.equals("/getbooks"))
    	 {
    		 r.setIssuedate(req.getParameter("t1"));
    		 r.setReturndate(req.getParameter("t2"));
    		 System.out.println("start date"+r.getIssuedate());
 			 System.out.println("end date"+r.getReturndate());
    		 ArrayList<RequestModel> al=new ArrayList<RequestModel>();
	    	 al=li.getBooks(r.getIssuedate(),r.getReturndate(),r);
	    	 out.print("<center><body><table border=1 cellpadding=7><tr><td>Book ID</td><td>Book Name</td><td>Sid</td><td>issude date</td><td>return date</td></tr>");
	    	 for(RequestModel r1: al)
	    	 {
	    		 out.print("<tr><td>"+r1.getBookid()+"</td><td>"+r1.getBookname()+"</td><td>"+r1.getStudentid()+"</td><td>"+r1.getIssuedate()+"</td><td>"+r1.getReturndate()+"</td></tr>");
	    	 }
    	 }
	 }
     public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
     {
         PrintWriter out=res.getWriter();
	     AdminModel am=new AdminModel();
	     String path=req.getServletPath();
	     if(path.equals("/adlogin"))
	     {
		   am.setUsername(req.getParameter("t1"));
		   am.setPassword(req.getParameter("t2"));
		   boolean b=li.adminLogin(am);
		   if(b)
		   {
			  RequestDispatcher rd=req.getRequestDispatcher("AdminOptions.html");
			  rd.forward(req, res);
		   }
		   else
		   {
			  RequestDispatcher rd=req.getRequestDispatcher("AdminLogin.html");
			  rd.forward(req, res);
			  out.print("<body><center><h2>Invalid Username/Password</h2></center></body>");
		   }
	     }
     }
}
