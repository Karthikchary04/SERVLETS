package project_controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project_Class_Interface.LibraryClass;
import project_Model.BookModel;
import project_Model.LibrarianModel;
import project_Model.RequestModel;
import project_Model.StudentModel;
@WebServlet(urlPatterns = {"/studentlogin","/studentregister","/studentpassword","/seebooks","/requestbook","/mybooks","/returnbook","/studentlogout"})
public class StudentController extends HttpServlet
{
    LibraryClass li;
	public void init() throws ServletException
	{
		super.init();
		li=new LibraryClass();
		
	}
	 public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	 {
		 String path=req.getServletPath();
    	 PrintWriter out=res.getWriter();
    	 LibrarianModel a=new LibrarianModel();
    	 BookModel bo=new BookModel();
    	 RequestModel r=new RequestModel();
    	 StudentModel s=new StudentModel();
    	 if(path.equals("/seebooks"))
     	 {
    		bo.setBookname(req.getParameter("t1"));
     		ArrayList<BookModel> al=new ArrayList<BookModel>();
     		al=li.viewBooksInLibrary(bo);
     		out.print("<center><table border=1 cellpadding=7 bgcolor=yellow><tr bgcolor=orange><td>Book ID</td><td>Book Name</td><td>Request Book</td></center>");
     		for(BookModel bo1: al)
     		{
     			out.print("<tr><td>"+bo1.getBookid()+"</td><td>"+bo1.getBookname()+"</td><td><a href=requestbook?id="+bo1.getBookid()+">Request Book</a></td></tr>");
     		}
     		out.print("<body><center><h3>Click here to go back<a href=StudentOptions.html>Options</a></h3></center></body>");
     	 }
    	 else if(path.equals("/mybooks"))
     	 {
     		ArrayList<RequestModel> al=new ArrayList<RequestModel>();
     		al=li.mybooks();
     		out.print("<center><table border=1 cellpadding=7 bgcolor=yellow><tr bgcolor=orange><td>Mybooks</td><td>Return Date</td><td>Return book</td></tr>");
     		for(RequestModel r1: al)
     		{
     			out.print("<tr><td>"+r1.getBookname()+"</td><td>"+r1.getReturndate()+"</td><td><a href=returnbook?id="+r1.getBookname()+">Return Book</a></td></tr>");
     		}
     		out.print("<body><center>Click Here for<a href=StudentOptions.html>Options</a></center></body>");
     	 }
    	 else if(path.equals("/requestbook"))
         {
     		 boolean b=false;
     		 r.setBookid(Integer.parseInt(req.getParameter("id")));
         	 b=li.requestBook(r);
         	 if(b)
         	 {
         		out.print("<body><center>Request sent<a href=seebooks>Go back</a></center></body>");
         	 }
         	 else
         	 {
         		 out.print("request failed");
         	 }
         }
    	 else if(path.equals("/returnbook"))
     	{
     		r.setBookname(req.getParameter("id"));
     		boolean b=false;
     		b=li.returnBook(r,bo);
     		if(b)
     		{
     			RequestDispatcher rd=req.getRequestDispatcher("mybooks");
     			rd.forward(req, res);
     			out.print("<body><center>Book Returned</center></body>");
     		}
     		else
     		{
     			out.print("<body><center>Book Returning failed</center></body>");
     		}
     	}
	 }
    public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
    {
    	
    	PrintWriter out=res.getWriter();
    	String path=req.getServletPath();
    	StudentModel s=new StudentModel();
    	BookModel bo=new BookModel();
    	RequestModel r=new RequestModel();
    	String fullname=null;
    	if(path.equals("/studentlogin"))
    	{
    		s.setUsername(req.getParameter("t1"));
    		s.setPassword(req.getParameter("t2"));
    		boolean b=li.studentLogin(s);
    		if(b)
    		{
    			HttpSession session =req.getSession();
    			session.setAttribute("name",s.getUsername());
    			RequestDispatcher rd=req.getRequestDispatcher("StudentOptions.html");
    			rd.forward(req, res);
    		}
    		else
    		{
    			RequestDispatcher rd=req.getRequestDispatcher("studentlogin.html");
    			rd.include(req, res);
    			out.print("Invalid username/password");
    		}
    	}
    	else if(path.equals("/studentregister"))                
    	{
    		s.setStudentid(Integer.parseInt(req.getParameter("t1").trim()));
    		s.setFullname(req.getParameter("t2"));
    		s.setUsername(req.getParameter("t3"));
    		s.setEmail(req.getParameter("t4"));
    		s.setPassword(req.getParameter("t5"));
    		boolean b=li.studentRegister(s);
    		if(b)
    		{
    			RequestDispatcher rd=req.getRequestDispatcher("studentregister.html");
    			rd.include(req, res);
    			out.print("<body><center><h3>Registered Sucessfully click here to Login<a href=studentlogin.html>Login</a></h3></center></body>");
    		}
    		else
    		{
    			RequestDispatcher rd=req.getRequestDispatcher("studentregister.html");
    			rd.include(req, res);
    			out.print("Registration Failed");
    		}
    	}
    	else if(path.equals("/studentpassword"))
    	{
    		boolean b=false;
    		s.setEmail(req.getParameter("t1"));
    		s.setPassword(req.getParameter("t2"));
    		b=li.studentForgot(s);
    		if(b)
    		{
    			RequestDispatcher rd=req.getRequestDispatcher("StudentForgot.html");
    			rd.include(req, res);
    			out.print("<bofy><center><h3>Password Changed Click Here To Login<a href=studentlogin.html>Login</a></h3></center></body>");
    		}
    		else
    		{
    			RequestDispatcher rd=req.getRequestDispatcher("StudentForgot.html");
    			rd.include(req, res);
    			out.print("<bofy><center><h3>Invalid Email</h3></center></body>");
    		}
    	}
    	else if(path.equals("/studentlogout"))
    	{
    		RequestDispatcher rd=req.getRequestDispatcher("studentlogin.html");
    		rd.forward(req, res);
    	}
    }
}
