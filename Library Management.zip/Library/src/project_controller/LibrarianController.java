package project_controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.h2.engine.Session;

import project_Class_Interface.LibraryClass;
import project_Model.LibrarianModel;
import project_Model.BookModel;
import project_Model.RequestModel;
import project_Model.StudentModel;
@WebServlet(urlPatterns = {"/librarianlogin","/librarianregister","/librarianpassword","/Addbook","/viewbooks","/updatestock","/update","/deletebook","/checkrequests","/issuebook","/issuebooktostudent","/librarianlogout"})
public class LibrarianController extends HttpServlet
{
	 LibraryClass li;
	 public void init() throws ServletException
	 {
		 super.init();
		 li=new LibraryClass();
	 }
	 public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	 {
		 String path=req.getServletPath();
    	 PrintWriter out=res.getWriter();
    	 LibrarianModel a=new LibrarianModel();
    	 BookModel bo=new BookModel();
    	 RequestModel r=new RequestModel();
    	 StudentModel s=new StudentModel();
    	 if(path.equals("/viewbooks"))
    	 {
    		 ArrayList<BookModel> al=new ArrayList<BookModel>();
    		 al=li.viewBooksInLibrary();
   			 out.print("<center><table border=1 cellpadding=7 bgcolor=yellow><tr bgcolor=orange><td>Book ID</td><td>Book Name</td><td>No.Of Books</td><td>Issued</td><td>Update Quantity</td><td>Delete Book</td></tr></center>");
   			 for(BookModel bo1: al)
   			 {
   				 out.print("<tr><td>"+bo1.getBookid()+"</td><td>"+bo1.getBookname()+"<td>"+bo1.getQuantity()+"<td>"+bo1.getIssued()+"</td><td><a href=updatestock?id="+bo1.getBookid()+">Update Quantity</a></td><td><a href=deletebook?del="+bo1.getBookid()+">Delete Book</a></td></tr>");
   			 }
   			 out.print("Click here to go back<a href=LibrarianOptions.html>Go back</a>");
   		}
    	 else if(path.equals("/updatestock"))
         {
        	 bo.setBookid(Integer.parseInt(req.getParameter("id")));
        	 ResultSet rs=li.updateSupporter(bo);
        	 try
        	 {
        		if(rs.next())
        		{
        	       out.print("<body><center><form action=update>Bookid:<input type=text value="+bo.getBookid()+" name=t1><br>Quantity:<input type=text value="+rs.getString(1)+" name=t2><br>");
        	       out.print("<input type=submit value=Update Quantity></form></center></body>");
                }
        	 }
        	 catch (Exception e) 
        	 {
				System.out.println(e);
			}
         }
    	 else if(path.equals("/checkrequests"))
         {
        	 ArrayList<RequestModel> al=new ArrayList<RequestModel>();
        	 al=li.checkBookRequestsFromStudents();
        	 out.print("<center><table border=1 cellpading=7><tr bgcolor=yellow><td>BookId</td><td>BookName</td><td>StudentId</td><td>Issue Book</td></tr></center>");
        	 for(RequestModel r1: al)
        	 {
        		 out.print("<tr><td>"+r1.getBookid()+"</td><td>"+r1.getBookname()+"</td><td>"+r1.getStudentid()+"</td><td><form action=issuebook><input type=hidden name=sid value="+r1.getStudentid()+"><input type=hidden name=bookid value="+r1.getBookid()+"><input type=submit  value=issuebook></form></td></tr>");
        	 }
        	 out.print("<body><center><h3>Click Here for Options<a href=LibrarianOptions.html>Options</a></h3></center></body>");
         }
    	 else if(path.equals("/issuebooktostudent"))
         {
        	 r.setBookid(Integer.parseInt(req.getParameter("t1")));
        	 r.setBookname(req.getParameter("t2"));
        	 r.setStudentid(Integer.parseInt(req.getParameter("t3")));
        	 r.setIssuedate(req.getParameter("t4"));
        	 r.setReturndate(req.getParameter("t5"));
        	 boolean b=li.issueBookToStudents(r,bo);
        	 if(b)
        	 {
        		 out.print("<body><center><h3>book issued<a href=checkrequests>go back</a></h3></center></body>");
        	 }
        	 else
        	 {
        		 out.print("book not issued");
        	 }
         }
    	 else if(path.equals("/issuebook"))
    	 { 
    		 r.setBookid(Integer.parseInt(req.getParameter("bookid").trim()));
    		 r.setStudentid(Integer.parseInt(req.getParameter("sid").trim()));
    		 r=li.issueBook(r);
    		 out.print("<body><center><form action=issuebooktostudent>BookId:<input type=text name=t1 value="+r.getBookid()+"><br>");
    		 out.print("Book Name:<input type=text name=t2 value="+r.getBookname()+"><br>");
    		 out.print("Student Id:<input type=text name=t3 value="+r.getStudentid()+"><br>");
    		 out.print("Issue Date:<input type=text name=t4 placeholder=YYYY-MM-DD><br>");
    		 out.print("Return Datr:<input type=text name=t5 placeholder=YYYY-MM-DD><br>");
    		 out.print("<input type=submit value=Issue Book></form></center></body>");
    	 }
    	 else if(path.equals("/update"))
         {
        	 bo.setBookid(Integer.parseInt(req.getParameter("t1").trim()));
        	 bo.setQuantity(Integer.parseInt(req.getParameter("t2").trim()));
        	 boolean b=li.updateBookQuantiy(bo);
        	 if(b)
        	 {
        		 RequestDispatcher rd=req.getRequestDispatcher("viewbooks");
        		 rd.forward(req,res);
        	 }
        	 else
        	 {
        		 out.print("failed");
        	 }
         }
    	 else if(path.equals("/deletebook"))
         {
        	 bo.setBookid(Integer.parseInt(req.getParameter("del")));
        	 boolean b=li.deleteBook(bo);
        	 if(b)
        	 {
        		 RequestDispatcher rd=req.getRequestDispatcher("/viewbooks");
        		 rd.forward(req, res);
        	 }
        	 else
        	 {
        		 out.print("failed");
        	 }
         }
    	 else if(path.equals("/Addbook"))
    	 {
    		 bo.setBookid(Integer.parseInt(req.getParameter("t1").trim()));
    		 bo.setBookname(req.getParameter("t2"));
    		 bo.setQuantity(Integer.parseInt(req.getParameter("t3").trim()));
    		 bo.setIssued(Integer.parseInt(req.getParameter("t4")));
    		 boolean b=li.addBooksInLibrary(bo);
    		 if(b)
    		 {
    			 RequestDispatcher rd=req.getRequestDispatcher("Addbook.html");
    			 rd.include(req,res);
    			 out.print("<body><center><h3>Book Added Go Back For Options<a href=LibrarianOptions.html>Options</a></h3></center></body>");
    		 }
    		 else
    		 {
    			 RequestDispatcher rd=req.getRequestDispatcher("Addbook.html");
    			 rd.include(req, res);
    			 out.print("<body><center><h3>Adding Book Failed!/Book Already Exists<br>Try Again</h3></center></body>");
    		 }
    	 } 
    	 else if(path.equals("/librarianlogout"))
         {
        	 RequestDispatcher rd=req.getRequestDispatcher("LibrarianLogin.html");
        	 rd.forward(req, res);
         }
	 }
     public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
     {
    	 String path=req.getServletPath();
    	 PrintWriter out=res.getWriter();
    	 LibrarianModel a=new LibrarianModel();
    	 BookModel bo=new BookModel();
    	 RequestModel r=new RequestModel();
    	 StudentModel s=new StudentModel();
    	 if(path.equals("/librarianlogin"))
    	 {
    		 a.setUsername(req.getParameter("t1"));
    		 a.setPassword(req.getParameter("t2"));
    		 boolean b=li.librarianLogin(a);
    		 if(b)
    		 {
    			 HttpSession session=req.getSession();
     			session.setAttribute("name",a.getUsername());
				RequestDispatcher rd=req.getRequestDispatcher("LibrarianOptions.html");
				rd.forward(req, res);
    		 }
    		 else
    		 {
    			 RequestDispatcher rd=req.getRequestDispatcher("LibrarianLogin.html");
    			 rd.include(req, res);
    			 out.print("invalid Username/Password");
    		 }
         }
    	 else if(path.equals("/librarianregister"))
    	 {
    		 a.setFullname(req.getParameter("t1"));
    		 a.setUsername(req.getParameter("t2"));
    		 a.setEmail(req.getParameter("t3"));
    		 a.setPassword(req.getParameter("t4"));
    		 boolean b=li.librarianRegister(a);
    		 if(b)
    		 {
    			 RequestDispatcher rd=req.getRequestDispatcher("LibrarianRegistration.html");
    			 rd.include(req,res);
    			 out.print("<center><h3>Registered Sucessfully Click here to Login<a href=LibrarianLogin.html>Login</a></h3></center>");
    		 }
    		 else
    		 {
    			 RequestDispatcher rd=req.getRequestDispatcher("LibrarianRegistration.html");
    			 rd.include(req,res);
    			 out.print("<center><h3>Registration Failed</h3></center>");
    		 
    		 }
    	 }
    	 else if(path.equals("/librarianpassword"))
    	 {
    		 a.setEmail(req.getParameter("t1"));
    		 a.setPassword(req.getParameter("t2"));
    		 boolean b=li.forgotPassword(a);
    		 if(b)
    		 {
    			 RequestDispatcher rd=req.getRequestDispatcher("Librarianforgot.html");
    			 rd.include(req, res);
    			 out.print("<body><center><h3>Password Changed Click Here To Login<a href=LibrarianLogin.html>Login</a></h3></center></body>");
    		 }
    		 else
    		 {
    			 RequestDispatcher rd=req.getRequestDispatcher("Librarianforgot.html");
    			 rd.include(req, res);
    			 out.print("<body><center><h3>Invalid Email</h3></center></body>");
    		 }
    	 }
     }
}
