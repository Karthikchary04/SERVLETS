package college_Models;

public class Course_Model 
{
    private int cid,coursefee;
    private String coursename;
	public int getCid() 
	{
		return cid;
	}
	public void setCid(int cid) 
	{
		this.cid = cid;
	}
	public String getCoursename() 
	{
		return coursename;
	}
	public void setCoursename(String coursename) 
	{
		this.coursename = coursename;
	}
	public int getCoursefee() 
	{
		return coursefee;
	}
	public void setCoursefee(int coursefee) 
	{
		this.coursefee = coursefee;
	}
}
