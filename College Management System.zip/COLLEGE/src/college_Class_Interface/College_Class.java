package college_Class_Interface;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.print.DocFlavor.READER;
import javax.servlet.http.HttpSession;

import college_Models.Course_Model;
import college_Models.Fee_Remainder_Model;
import college_Models.Lecturer_Model;
import college_Models.Marks_Model;
import college_Models.Principal_Model;
import college_Models.Recption_Model;
import college_Models.Student_Model;


public class College_Class implements College_Interface
{
	static Connection con=null;
	public static Connection getConnectionObject()
	{
		try
		{
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","karthik","Karthik@04");
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return con;
	}
	public boolean principalLogin(Principal_Model p) 
	{
		boolean b=false;
		ResultSet rs=null;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select username,password from collegeprincipal where username='"+p.getUsername()+"' and password='"+p.getPassword()+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return b;
	}
	public int getPreviousLecturerId()
	{
		ResultSet rs=null;
		int lid=0;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select max(id) from collegelecturers");
			if(rs.next())
			{
				lid=rs.getInt(1);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return lid;
	}
	public boolean addLecturer(Lecturer_Model l) 
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{
			PreparedStatement pst=con.prepareStatement("insert into collegelecturers values(?,?,?,?,?,?)");
			pst.setInt(1,l.getLid());
			pst.setString(2,l.getFullname());
			pst.setString(3,l.getUsername());
			pst.setString(4,l.getEmail());
			pst.setString(5,l.getSubject());
			pst.setString(6,l.getPassword());
			int i=pst.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
		   System.out.println(e);	
		}
		return b;
	}
	public int getPreviousReciptionistId()
	{
		int rid=0;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select max(id) from collegereciption");
			if(rs.next())
			{
				rid=rs.getInt(1);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return rid;
	}
	public boolean addRecptionist(Recption_Model r)
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{
			PreparedStatement pst=con.prepareStatement("insert into collegereciption values(?,?,?,?,?)");
			pst.setInt(1,r.getRid());
			pst.setString(2,r.getFullname());
			pst.setString(3,r.getUsername());
			pst.setString(4,r.getEmail());
			pst.setString(5,r.getPassword());
			int i=pst.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public int getPreviousCourseId()
	{
		int cid=0;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select max(cid) from collegecources");
			if(rs.next())
			{
				cid=rs.getInt(1);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return cid;
	}
	public boolean addCourse(Course_Model c) 
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{
			PreparedStatement pst=con.prepareStatement("insert into collegecources values(?,?,?)");
			pst.setInt(1,c.getCid());
			pst.setString(2,c.getCoursename());
			pst.setInt(3,c.getCoursefee());
			int i=pst.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<Lecturer_Model> viewlecturers() 
	{
		ArrayList<Lecturer_Model> al=new ArrayList<Lecturer_Model>();
		ResultSet rs=null;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from collegelecturers");
			while(rs.next())
			{
				Lecturer_Model l=new Lecturer_Model();
				l.setLid(rs.getInt(1));
				l.setFullname(rs.getString(2));
				l.setUsername(rs.getString(3));
				l.setEmail(rs.getString(4));
				l.setSubject(rs.getString(5));
				al.add(l);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public ArrayList<Recption_Model> viewRecptionist() 
	{
		ArrayList<Recption_Model> al=new ArrayList<Recption_Model>();
		ResultSet rs=null;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from collegereciption	");
			while(rs.next())
			{
				Recption_Model r=new Recption_Model();
				r.setRid(rs.getInt(1));
				r.setFullname(rs.getString(2));
				r.setUsername(rs.getString(3));
				r.setEmail(rs.getString(4));
				al.add(r);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public ArrayList<Course_Model> viewCources() 
	{
		ArrayList<Course_Model> al=new ArrayList<Course_Model>();
		ResultSet rs=null;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from collegecources");
			while(rs.next())
			{
				Course_Model c=new Course_Model();
				c.setCid(rs.getInt(1));
				c.setCoursename(rs.getString(2));
				c.setCoursefee(rs.getInt(3));
				al.add(c);
			}
		}
		catch (Exception e) 
		{
		   System.out.println(e);	
		}
		return al;
	}
	
	
//====================================================================================================================================================//
	//Lecturer Related Methods//
	public boolean lecturerLogin(Lecturer_Model l)
	{
	    boolean b=false;
	    ResultSet rs=null;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select username,password,id from collegelecturers where username='"+l.getUsername()+"' and password='"+l.getPassword()+"'");
			if(rs.next())
			{
				l.setLid(rs.getInt(3));
				b=true;
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return b;
	}
	public boolean createPassword(Lecturer_Model l) 
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			int i=st.executeUpdate("update collegelecturers set password='"+l.getPassword()+"' where email='"+l.getEmail()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return b;
	}
	public ArrayList<Student_Model> checkMyStudents(Lecturer_Model l) 
	{
	    ArrayList<Student_Model> al=new ArrayList<Student_Model>();
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			try
			{
				
				ResultSet rs=st.executeQuery("select subject from collegelecturers where id='"+l.getLid()+"'");
				if(rs.next())
				{
					l.setSubject(rs.getString(1));
					ResultSet rs1=st.executeQuery("select * from collegestudents where course='"+l.getSubject()+"'");
					while(rs1.next())
					{
						Student_Model s=new Student_Model();
						s.setSid(rs1.getInt(1));
						s.setStudentName(rs1.getString(2));
						s.setEmail(rs1.getString(3));
						s.setDob(rs1.getInt(4));
						s.setCourse(rs1.getString(5));
						s.setFee(rs1.getInt(6));
						al.add(s);
					}
				}
			}
			catch (Exception e) 
			{
				System.out.println(e);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
	    return al;
	}
	public ArrayList<Student_Model> enterStudentMarks(Student_Model s)
	{
		ArrayList<Student_Model> al=new ArrayList<Student_Model>();
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select sid,studentname,course from collegestudents where sid='"+s.getSid()+"'");
			while(rs.next())
			{
				Student_Model s1=new Student_Model();
				s1.setSid(rs.getInt(1));
				s1.setStudentName(rs.getString(2));
				s1.setCourse(rs.getString(3));
				al.add(s1);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public boolean enterInternalMarksOfStudent(Marks_Model m) 
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			int i=st.executeUpdate("update collegestudentmarks set internalmarks='"+m.getInternalmarks()+"' where sid='"+m.getSid()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return b;
	}
	public boolean enterExternalMarksOfStudent(Marks_Model m) 
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			int i=st.executeUpdate("update collegestudentmarks set externalmarks='"+m.getExternalmarks()+"' where sid='"+m.getSid()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return b;
	}
	public boolean enterSemesterMarksOfStudent(Marks_Model m) 
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			int i=st.executeUpdate("update collegestudentmarks set semestermarks='"+m.getSemestermarks()+"' where sid='"+m.getSid()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return b;
	}
	public ArrayList<Marks_Model> enterTotalMarksOfStudent(Marks_Model m) 
	{
		ArrayList<Marks_Model> al=new ArrayList<Marks_Model>();
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from collegestudentmarks where sid='"+m.getSid()+"'");
			while(rs.next())
			{
				Marks_Model m1=new Marks_Model();
				m1.setSid(rs.getInt(1));
				m1.setStudentname(rs.getString(2));
				m1.setCourse(rs.getString(3));
				m1.setInternalmarks(rs.getInt(4));
				m1.setExternalmarks(rs.getInt(5));
				m1.setSemestermarks(rs.getInt(6));
				m1.setTotalmarks(rs.getInt(7));
				al.add(m1);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public String gradesOfStudents(int totalmarks) 
	{
		String grade=null;
		if(totalmarks>=85)
		{
			grade="A";
		}
		else if(totalmarks>=75)
		{
			grade="B";
		}
		else if(totalmarks>=65)
		{
			grade="C";
		}
		else if(totalmarks>=55)
		{
			grade="D";
		}
		else if(totalmarks>=40)
		{
			grade="E";
		}
		else
		{
			grade="Failed";
		}
		return grade;
	}
	public boolean totalMarksOfStudent(Marks_Model m) 
	{
        boolean b=false;
        con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			m.setGrade(gradesOfStudents(m.getTotalmarks()));
			int i=st.executeUpdate("update collegestudentmarks set internalmarks='"+m.getInternalmarks()+"',externalmarks='"+m.getExternalmarks()+"',semestermarks='"+m.getSemestermarks()+"',totalmarks='"+m.getTotalmarks()+"',grade='"+m.getGrade()+"' where sid='"+m.getSid()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return b;
	}
	public ArrayList<Marks_Model> checkMarksOfStudents(Lecturer_Model l) 
	{
		ArrayList<Marks_Model> al=new ArrayList<Marks_Model>();
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select subject from collegelecturers where id='"+l.getLid()+"'");
			if(rs.next())
			{
				l.setSubject(rs.getString(1));
			    ResultSet rs1=st.executeQuery("select * from collegestudentmarks where course='"+l.getSubject()+"'");
			    while(rs1.next())
			    {
				  Marks_Model m1=new Marks_Model();
				  m1.setSid(rs1.getInt(1));
				  m1.setStudentname(rs1.getString(2));
				  m1.setCourse(rs1.getString(3));
				  m1.setInternalmarks(rs1.getInt(4));
			      m1.setExternalmarks(rs1.getInt(5));
				  m1.setSemestermarks(rs1.getInt(6));
				  m1.setTotalmarks(rs1.getInt(7));
				  m1.setGrade(rs1.getString(8));
				  al.add(m1);
			    }
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;		
	}
	
	
   //==================================================================================================================================================//
	//Reciptionist Related Methods//
	
	public boolean reciptionistLogin(Recption_Model r) 
	{
		boolean b=false;
		ResultSet rs=null;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select username,password from collegereciption where username='"+r.getUsername()+"' and password='"+r.getPassword()+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return b;
	}
	public boolean reciptionistCreatePassword(Recption_Model r) 
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			int i=st.executeUpdate("update collegereciption set password='"+r.getPassword()+"' where email='"+r.getEmail()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return b;
	}
	public int getPreviousStudentId()
	{
		int sid=0;
		con=College_Class.getConnectionObject();		
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select max(sid) from collegestudents");
			if(rs.next())
			{
			   sid=rs.getInt(1);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return sid;
	}
	public ArrayList<Course_Model> getAllCources()
	{
		ArrayList<Course_Model> al=new ArrayList<Course_Model>();
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select coursename from collegecources");
			while(rs.next())
			{
				Course_Model c=new Course_Model();
				c.setCoursename(rs.getString(1));
				al.add(c);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public boolean reciptionistAddStudents(Student_Model s,Marks_Model  m) 
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{ 
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select coursefee from collegecources where coursename='"+s.getCourse()+"'");
			if(rs.next())
			{
				s.setFee(rs.getInt(1));
				PreparedStatement pst=con.prepareStatement("insert into collegestudents values(?,?,?,?,?,?,?,?)");
				pst.setInt(1,s.getSid());
				pst.setString(2,s.getStudentName());
				pst.setString(3,s.getEmail());
				pst.setInt(4,s.getDob());
				pst.setString(5,s.getCourse());
				pst.setInt(6,s.getFee());
				pst.setInt(7,s.getPaid());
				pst.setInt(8,s.getFee());
				int i=pst.executeUpdate();
				PreparedStatement pst1=con.prepareStatement("insert into collegestudentmarks values(?,?,?,?,?,?,?,?)");
				pst1.setInt(1,s.getSid());
				pst1.setString(2,s.getStudentName());
				pst1.setString(3,s.getCourse());
				pst1.setInt(4,m.getInternalmarks());
				pst1.setInt(5,m.getExternalmarks());
				pst1.setInt(6,m.getSemestermarks());
				pst1.setInt(7,m.getTotalmarks());
				pst1.setString(8,m.getGrade());
				int j=pst1.executeUpdate();
				if(i>0 && j>0)
				{
					b=true;
				}
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<Student_Model> viewAllStudents() 
	{
		ArrayList<Student_Model> al=new ArrayList<Student_Model>();
		ResultSet rs=null;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from collegestudents");
			while(rs.next())
			{
				Student_Model s=new Student_Model();
				s.setSid(rs.getInt(1));
				s.setStudentName(rs.getString(2));
				s.setEmail(rs.getString(3));
				s.setDob(rs.getInt(4));
				s.setCourse(rs.getString(5));
				s.setFee(rs.getInt(6));
				s.setPaid(rs.getInt(7));
				s.setDue(rs.getInt(8));
				al.add(s);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public boolean sendFeeRemainderToStudent(Fee_Remainder_Model f) 
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select sid,studentname,course,fee,paid,due from collegestudents where sid='"+f.getSid()+"'");
			if(rs.next())
			{
			   f.setSid(rs.getInt(1));
			   f.setStudentname(rs.getString(2));
			   f.setCourse(rs.getString(3));
			   f.setFee(rs.getInt(4));
			   f.setPaid(rs.getInt(5));
			   f.setDue(rs.getInt(6));
			   PreparedStatement pst=con.prepareStatement("insert into collegefeeremainder values(?,?,?,?,?,?)");
			   pst.setInt(1,f.getSid());
			   pst.setString(2,f.getStudentname());
			   pst.setString(3,f.getCourse());
			   pst.setInt(4,f.getFee());
			   pst.setInt(5,f.getPaid());
			   pst.setInt(6,f.getDue());
			   int i=pst.executeUpdate();
			   if(i>0)
			   {
				   b=true;
			   }
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<Student_Model> checkStudentsByCourse(Course_Model c) 
	{
		ArrayList<Student_Model> al=new ArrayList<Student_Model>();
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select coursename from collegecources where cid='"+c.getCid()+"'");
			if(rs.next())
			{
				c.setCoursename(rs.getString(1));
			    ResultSet rs1=st.executeQuery("select * from collegeStudents where course='"+c.getCoursename()+"'");
			    while(rs1.next())
			    {
			       Student_Model s=new Student_Model();
			       s.setSid(rs1.getInt(1));
			       s.setStudentName(rs1.getString(2));
			       s.setEmail(rs1.getString(3));
			       s.setDob(rs1.getInt(4));
			       s.setCourse(rs1.getString(5));
			       s.setFee(rs1.getInt(6));
			       al.add(s);
			    }
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
	    return al;
	}
	
	
	//============================================================================================================================================//
	//Student Related Menthods//
	
	public boolean stuedentLogin(Student_Model s) 
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select sid,dob from collegestudents where sid='"+s.getSid()+"' and dob='"+s.getDob()+"'");
			if(rs.next())
			{
				s.setSid(rs.getInt(1));
				b=true;
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<Fee_Remainder_Model> checkFeeRemainders(Student_Model s) 
	{
		ArrayList<Fee_Remainder_Model> al=new ArrayList<Fee_Remainder_Model>();
		ResultSet rs=null;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from collegefeeremainder where sid='"+s.getSid()+"'");
			while(rs.next())
			{
				Fee_Remainder_Model f=new Fee_Remainder_Model();
				f.setSid(rs.getInt(1));
				f.setStudentname(rs.getString(2));
				f.setCourse(rs.getString(3));
				f.setFee(rs.getInt(4));
				f.setPaid(rs.getInt(5));
				f.setDue(rs.getInt(6));
				al.add(f);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public ArrayList<Fee_Remainder_Model> feePaymentForm(Fee_Remainder_Model f)
	{
		ArrayList<Fee_Remainder_Model> al=new ArrayList<Fee_Remainder_Model>();
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select sid,fee,paid,due from collegefeeremainder where sid='"+f.getSid()+"'");
			while(rs.next())
			{
				Fee_Remainder_Model f1=new Fee_Remainder_Model();
				f1.setSid(rs.getInt(1));
				f1.setFee(rs.getInt(2));
				f1.setPaid(rs.getInt(3));
				f1.setDue(rs.getInt(4));
				al.add(f1);
			}
		}
		catch (Exception e) 
		{
		    System.out.println(e);	
		}
		return al;
	}
	public boolean payDueAmount(Fee_Remainder_Model f) 
	{
		boolean b=false;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			int i=st.executeUpdate("update collegestudents set paid='"+(f.getPaid()+(f.getPay()))+"',due='"+(f.getDue()-(f.getPay()))+"' where sid='"+f.getSid()+"'");
			int j=st.executeUpdate("update collegefeeremainder set paid='"+(f.getPaid()+(f.getPay()))+"',due='"+(f.getDue()-(f.getPay()))+"' where sid='"+f.getSid()+"'");
			if(i>0 && j>0)
			{
					b=true;
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<Student_Model> checkMyFeeStructure(Student_Model s1) 
	{
		ArrayList<Student_Model> al=new ArrayList<Student_Model>();
		ResultSet rs=null;
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from collegestudents where sid='"+s1.getSid()+"'");
			while(rs.next())
			{
				Student_Model s=new Student_Model();
				s.setSid(rs.getInt(1));
				s.setStudentName(rs.getString(2));
				s.setEmail(rs.getString(3));
				s.setDob(rs.getInt(4));
				s.setCourse(rs.getString(5));
				s.setFee(rs.getInt(6));
				s.setPaid(rs.getInt(7));
				s.setDue(rs.getInt(8));
				al.add(s);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public ArrayList<Marks_Model> checkMyResult(Student_Model s) 
	{
		ArrayList<Marks_Model> al=new ArrayList<Marks_Model>();
		con=College_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from collegestudentmarks where sid='"+s.getSid()+"'");
			while(rs.next())
			{
				Marks_Model m1=new Marks_Model();
				m1.setSid(rs.getInt(1));
				m1.setStudentname(rs.getString(2));
				m1.setCourse(rs.getString(3));
				m1.setInternalmarks(rs.getInt(4));
				m1.setExternalmarks(rs.getInt(5));
				m1.setSemestermarks(rs.getInt(6));
				m1.setTotalmarks(rs.getInt(7));
				m1.setGrade(rs.getString(8));
				al.add(m1);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
}
