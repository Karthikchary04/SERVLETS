package project_controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import project_class.dao_Class;
import project_model.Cart;
import project_model.model;

@WebServlet(urlPatterns = {"/addproducts","/search","/sorting","/addtocart","/","/reqviewproduct","/addproductsform","/viewcart"})
public class controller extends HttpServlet
{
	private final String cloud="D://cloud";
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
     {
    	 String path=req.getServletPath();
    	 model m=new model();
    	 PrintWriter out=res.getWriter();
    	 if(path.equals("/addproducts"))
    	 {
    		 if(ServletFileUpload.isMultipartContent(req))
    		 {
    			 try
    			 {
    				 List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(req);
    				 for(FileItem item: multiparts)//for(model m:al)
    				 {
    					 if(!item.isFormField())
    					 {
    						 String picname=new File(item.getName()).getName();
    						 item.write(new File(cloud+File.separator+picname));
    						 m.setPicname(picname);
    					 }
    					 else
    					 {
    						 if(item.getFieldName().equals("t1"))
    						 {
    							 m.setPname(item.getString());
    						 }
    						 if(item.getFieldName().equals("t2"))
    						 {
    							 m.setPrice(Integer.parseInt(item.getString()));
    						 }
    						 if(item.getFieldName().equals("t3"))
    						 {
    							 m.setType(item.getString());
    						 }
    					 }
    				 }
    				 boolean b=new dao_Class().addProduct(m);
    				 if(b)
    				 {
    					 RequestDispatcher rd=req.getRequestDispatcher("addproducts.jsp");
    					 rd.include(req, res);
    					 out.print("Product Added Sucessfully");
    				 }
    				 else 
    				 {
    					 RequestDispatcher rd=req.getRequestDispatcher("addproducts.jsp");
    					 rd.include(req, res);
    					 out.print("<center>Product Adding Failed</center>");
					 }
    			 }
    			 catch (Exception e) 
    			 {
					System.out.println(e);
    			 }
    		 }
    	 }
     }
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
    {
   	 String path=req.getServletPath();
   	 model m=new model();
   	 Cart c=new Cart();
   	 PrintWriter out=res.getWriter();
   	 if(path.equals("/"))
   	 {
   		 RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
   		 rd.forward(req, res);
   	 }
   	 else if(path.equals("/addproductsform"))
  	 {
  		 RequestDispatcher rd=req.getRequestDispatcher("addproducts.jsp");
  		 rd.forward(req, res);
  	 }
   	else if(path.equals("/search"))
	 {
		 m.setType(req.getParameter("t1"));
		 HttpSession session=req.getSession();
		 session.setAttribute("sortedorder",m.getType());
		 ArrayList<model> al=new ArrayList<model>();
		 al=new dao_Class().searchProducts(m);
		 req.setAttribute("result",al);
		 if(al!=null)
		 {
			 File f=new File("D://cloud");
			 File arr[]=f.listFiles();
			 req.setAttribute("images",arr);
			 RequestDispatcher rd=req.getRequestDispatcher("searchproducts.jsp");
			 rd.forward(req, res);
		 }
		 else
		 {
			 RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
			 rd.forward(req, res);
		 }
	 }
   	 else if(path.equals("/sorting"))
    	 {
    		 String value=req.getParameter("value");
    		 HttpSession session=req.getSession();
    		 m.setType(session.getAttribute("sortedorder").toString());
    		 ArrayList<model> al=new ArrayList<model>();
    		 al=new dao_Class().sortedResult(m,value);
    		 req.setAttribute("result",al);
    		 if(al!=null)
    		 {
    			 File f=new File("D://cloud");
    			 File arr[]=f.listFiles();
    			 req.setAttribute("images",arr);
    			 RequestDispatcher rd=req.getRequestDispatcher("searchproducts.jsp");
    			 rd.forward(req, res);
    		 }
    		 else
    		 {
    			 RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
    			 rd.forward(req, res);
    		 }
    	 }
    	 else if(path.equals("/reqviewproduct"))
    	 {
    		 m.setPname(req.getParameter("name"));
    		 ArrayList<model> al=new ArrayList<model>();
    		 al=new dao_Class().viewproduct(m);
    		 req.setAttribute("view",al);
    		 if(al!=null)
    		 {
    			 File f=new File("D://cloud");
    		     File arr[]=f.listFiles();
    		     req.setAttribute("productimage",arr);
    			 RequestDispatcher rd=req.getRequestDispatcher("viewproduct.jsp");
    		     rd.forward(req, res);
    		 }
    	 }
    	 else if(path.equals("/addtocart"))
    	 {
    		 c.setPname(req.getParameter("pname"));
    		 c.setQuantity(Integer.parseInt(req.getParameter("qty")));
    		 c.setType(new dao_Class().addToCart(c));
    		 if(c.getType()!=null)
    		 {
    			 req.setAttribute("msg","Product Added To Cart");
    			 out.print(req.getAttribute("msg"));
    			 RequestDispatcher rd=req.getRequestDispatcher("search?t1="+c.getType()+"");
    			 rd.forward(req, res);
    		 }
    		 else
    		 {
    			 req.setAttribute("msg","Adding Product to Cart is Failed...... Try Again!");
    			 out.print(req.getAttribute("msg"));
    			 RequestDispatcher rd=req.getRequestDispatcher("search?t1="+c.getType()+"");
    			 rd.forward(req, res);
    		 }
    	 }
    	 else if(path.equals("/viewcart"))
    	 {
    		 ArrayList<Cart> al=new ArrayList<Cart>();
    		 al=new dao_Class().viewCart();
    		 req.setAttribute("cart",al);
    		 if(al!=null)
    		 {
    			 File f=new File("D://cloud");
    		     File arr[]=f.listFiles();
    		     req.setAttribute("cartimages",arr);	 
    		     RequestDispatcher rd=req.getRequestDispatcher("viewcart.jsp");
    		     rd.forward(req, res);
    		 }
    	 }
     }
     
}
