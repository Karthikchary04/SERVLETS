package project_class;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import project_model.Cart;
import project_model.model;

public class dao_Class 
{
	static Connection con=null;
	public static Connection getConnectionObject()
	{
		try 
		{
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","karthik","Karthik@04");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}
	public boolean addProduct(model m)
	{
		boolean b=false;
		con=dao_Class.getConnectionObject();
		try
		{
			PreparedStatement pst=con.prepareStatement("insert into picexample values(?,?,?,?)");
			pst.setString(1,m.getPname());
			pst.setInt(2,m.getPrice());
			pst.setString(3,m.getPicname());
			pst.setString(4,m.getType());
			int i=pst.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<model> searchProducts(model m)
	{
		ArrayList<model> al=new ArrayList<model>();
		ResultSet rs=null;
		con=dao_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select pname,price,picname from picexample where type like '%"+m.getType().toLowerCase()+"%'");
			while(rs.next())
			{
				model m1=new model();
				m1.setPname(rs.getString(1));
				m1.setPrice(rs.getInt(2));
				m1.setPicname(rs.getString(3));
				al.add(m1);
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return al;
	}
	public ArrayList<model> sortedResult(model m,String req)
	{
		ArrayList<model> al=new ArrayList<model>();
		ResultSet rs=null;
		con=dao_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			if(req.equals("lowtohigh"))
			{
				rs=st.executeQuery("select pname,price,picname from picexample where type like '%"+m.getType().toLowerCase()+"%' order by price");
			}
			else
			{
				rs=st.executeQuery("select pname,price,picname from picexample where type like '%"+m.getType().toLowerCase()+"%' order by price desc");
			}
			while(rs.next())
			{
				model m1=new model();
				m1.setPname(rs.getString(1));
				m1.setPrice(rs.getInt(2));
				m1.setPicname(rs.getString(3));
				al.add(m1);
			}
		}
         catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public String addToCart(Cart c)
	{
		boolean b=false;
		con=dao_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select price,type,picname from picexample where pname='"+c.getPname()+"'");
			if(rs.next())
			{
				c.setPrice(rs.getInt(1));
				c.setType(rs.getString(2));
				c.setPicname(rs.getString(3));
				c.setTotal(c.getPrice()*c.getQuantity());
				PreparedStatement pst=con.prepareStatement("insert into cart values(?,?,?,?,?)");
				pst.setString(1,c.getPname());
				pst.setInt(2,c.getPrice());
				pst.setInt(3,c.getQuantity());
				pst.setInt(4,c.getTotal());
				pst.setString(5,c.getPicname());
				int i=pst.executeUpdate();
				if(i>0)
				{
					return c.getType();
				}
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return c.getType();
	}
	public ArrayList<model> viewproduct(model m)
	{
		ArrayList<model> al=new ArrayList<model>();
		ResultSet rs=null;
		con=dao_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from picexample where pname='"+m.getPname()+"'");
			if(rs.next())
			{
				m.setPname(rs.getString(1));
				m.setPrice(rs.getInt(2));
				m.setPicname(rs.getString(3));
				m.setType(rs.getString(4));
				al.add(m);
			}
		}
		catch (Exception e)
		{
		    System.out.println(e);	
		}
		return al;		
	}
	public ArrayList<Cart> viewCart()
	{
		ArrayList<Cart> al=new ArrayList<Cart>();
		ResultSet rs=null;
		con=dao_Class.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from cart");
			while(rs.next())
			{
				Cart c=new Cart();
				c.setPname(rs.getString(1));
				c.setPrice(rs.getInt(2));
				c.setQuantity(rs.getInt(3));
				c.setTotal(rs.getInt(4));
				c.setPicname(rs.getString(5));
				al.add(c);
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return al;
	}
}
