package projectModel;

public class ProductModel 
{
	private int pid,quantity,issued;
	private String productname;
	public int getPid() 
	{
		return pid;
	}
	public void setPid(int pid) 
	{
		this.pid = pid;
	}
	public int getQuantity() 
	{
		return quantity;
	}
	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}
	public int getIssued() 
	{
		return issued;
	}
	public void setIssued(int issued)
	{
		this.issued = issued;
	}
	public String getProductname() 
	{
		return productname;
	}
	public void setProductname(String productname) 
	{
		this.productname = productname;
	}

}
