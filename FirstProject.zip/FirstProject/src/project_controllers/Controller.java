package project_controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.ArrayList;
import controller_Class.MainClass;
import projectModel.CustomerModel;
import projectModel.Model;
import projectModel.ProductModel;
@WebServlet(urlPatterns= {"/login","/register","/password","/view","/requpdate","/detailsupdate","/reqdelete","/detailsview","/addproducts","/productsview","/updateproduct","/UpdateProductDetails","/deleteproducts","/viewproductsbyid","/customerlogin","/customerRegister","/customerpassword","/customerView","/customerproducts"})
public class Controller extends HttpServlet
{
	 public void service(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	    {
	    	PrintWriter out=res.getWriter();
	    	String path=req.getServletPath();
	    	Model m=new Model();
	    	ProductModel p=new ProductModel();
	    	CustomerModel c=new CustomerModel();
	    	if(path.equals("/login"))
	    	{
	    		m.setUserName(req.getParameter("t1"));
	    		m.setPassword(req.getParameter("t2"));
	    		boolean b=new MainClass().login(m);
	    		if(b)
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("view.html");
	    			rd.include(req, res);
	    		}
	    		else
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("index.html");
	    			rd.include(req, res);
	    			out.print("invalid user");
	    		}
	    	}
	    	else if(path.equals("/register"))
	    	{
	    		m.setFullName(req.getParameter("t1"));
	    		m.setUserName(req.getParameter("t2"));
	    		m.setEmail(req.getParameter("t3"));
	    		m.setPassword(req.getParameter("t4"));
	    		boolean b=new MainClass().register(m);
	    		if(b)
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("RegisterPage.html");
	    			rd.include(req, res);
	    			out.print("<body><center><h3>Registered sucessfully <a href=index.html>login</a></h3></center></body>");
	    		}
	    		else
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("RegisterPage.html");
	    			rd.include(req, res);
	    			out.print("Registration failed");
	    		}
	    	}
	    	else if(path.equals("/password"))
	    	{
	    		m.setEmail(req.getParameter("t1"));
	    		m.setPassword(req.getParameter("t2"));
	    		boolean b=new MainClass().forgot(m);
	    		if(b)
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("forgot.html");
	    			rd.include(req, res);
	    			out.print("<body><center><h3>Password changed click here to login<a href=index.html>Login</a><h3></center></body>");
	    		}
	    		else
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("forget.html");
	    			rd.forward(req, res);
	    			out.print("invalid email");
	    		}
	    	}
	    	else if(path.equals("/view"))
	    	{
	    		ArrayList<Model> al=new ArrayList<Model>();
				al=new MainClass().viewAll();
				out.print("<table  border=1><tr><th>FullName</th><th>UserName</th><th>Email</th><th>Update</th><th>Delete</th></tr>");
				for(Model m1: al)
				{
					out.print("<tr><td>"+m1.getFullName()+"</td><td>"+m1.getUserName()+"</td><td>"+m1.getEmail()+"</td><td><a href=requpdate?id="+m1.getFullName()+">Update</a></td><td><a href=reqdelete?del="+m1.getFullName()+">Delete</a></td>");
				}
	    	}
	    	else if(path.equals("/requpdate"))
	    	{
	    		ResultSet rs=null;
	    		m.setFullName(req.getParameter("id"));
	    		rs=new MainClass().update(m);
	    		try
	    		{
	    			while(rs.next())
	    			{
	    				out.print("<body><form action=detailsupdate>FullName: <input type=text name=t1 readonly value="+rs.getString(1)+"><br>");
	    				out.print("Useranme: <input type=text name=t2 value="+rs.getString(2)+"><br>");
	    				out.print("Email: <input type=text name=t3 value="+rs.getString(3)+"><br>");
	    				out.print("<input type=submit value=update><input type=Reset value=clear></form>");
	    			}
	    		}
	    		catch(Exception e)
	    		{
	    			System.out.println(e);
	    		}
	    	}
	    	else if(path.equals("/detailsupdate"))
	    	{
	    		m.setFullName(req.getParameter("t1"));
	    		m.setUserName(req.getParameter("t2"));
	    		m.setEmail(req.getParameter("t3"));
	    		boolean b=new MainClass().updateDetails(m);
				if(b)
				{
					RequestDispatcher rd=req.getRequestDispatcher("view");
					rd.forward(req, res);
				}
				else
				{
					out.print("failed");
				}
	    	}
	    	else if(path.equals("/reqdelete"))
	    	{
	    		m.setFullName(req.getParameter("del"));
	    		boolean b=new MainClass().delete(m.getFullName());
	    		if(b)
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("view");
					rd.forward(req, res);
	    		}
	    		else
	    		{
	    			out.print("failed");
	    		}
	    	}
	    	else if(path.equals("/detailsview"))
	    	{
	    		System.out.println(req.getParameter("t1"));
	    		m=new MainClass().viewDetailsById(req.getParameter("t1"));
	    		out.print("<table border=1 cellpadding=7><tr bgcolor=yellow><td>fullname</td><td>username</td><td>Email ID</td></tr>");
	    	    out.print("<tr><td>"+m.getFullName()+"</td><td>"+m.getUserName()+"</td><td>"+m.getEmail()+"");
	    	}
	    	else if(path.equals("/addproducts"))
	    	{
	    		p.setPid(Integer.parseInt(req.getParameter("t1")));
	    		p.setProductname(req.getParameter("t2"));
	    		p.setQuantity(Integer.parseInt(req.getParameter("t3")));
	            p.setIssued(Integer.parseInt(req.getParameter("t4")));
	    		boolean b=new MainClass().addProduct(p);
	    		if(b)
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("AddProduct.html");
	    			rd.include(req, res);
	    			out.print("<body><center><h3>porduct added sucessfully <a href=view.html>go back</a></h3></center></body>");
	    		}
	    		else
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("AddProduct.html");
	    			rd.forward(req, res);
	    			out.print("Adding Product failed");
	    		}
	    	}
	    	else if(path.equals("/productsview"))
	    	{
	    		ArrayList<ProductModel> al=new ArrayList<ProductModel>();
	    		al=new MainClass().viewAllProducts();
	    		out.print("<table border=1 cellpadding=7><tr bgcolor=yellow><td>Product id</td><td>Product Name</td><td>Quantity</td><td>Issued</td><td>update</td><td>delete</td></tr>");
	    		   for(ProductModel p1: al)
	    		   {
	    			   out.print("<tr><td>"+p1.getPid()+"</td><td>"+p1.getProductname()+"</td><td>"+p1.getQuantity()+"</td><td>"+p1.getIssued()+"</td><td><a href=updateproduct?id="+p1.getPid()+">update</a></td><td><a href=deleteproducts?del="+p1.getPid()+">delete</a></td></tr>");		
	    		   }
	    	}
	    	else if(path.equals("/updateproduct"))
	    	{
	    		ResultSet rs=null;
	    		p.setPid(Integer.parseInt(req.getParameter("id")));
	    		rs=new MainClass().updateProducts(p.getPid());
	    		try
	    		{
	    			while(rs.next())
	    			{
	    				out.print("<body><form action=UpdateProductDetails>Product Id: <input type=text name=t1 readonly value="+rs.getString(1)+"><br>");
	    				out.print("Product name: <input type=text name=t2 value="+rs.getString(2)+"><br>");
	    				out.print("Quantity: <input type=text name=t3 value="+rs.getString(3)+"><br>");
	    				out.print("Issued: <input type=text name=t4 value="+rs.getString(4)+"><br>");
	    				out.print("<input type=submit value=update><input type=Reset value=clear></form>");
	    			}
	    		}
	    		catch(Exception e)
	    		{
	    			System.out.println(e);
	    		}
	    	}
	    	else if(path.equals("/UpdateProductDetails"))
	    	{
	    		p.setPid(Integer.parseInt(req.getParameter("t1").trim()));
	    		p.setProductname(req.getParameter("t2"));
	    		p.setQuantity(Integer.parseInt(req.getParameter("t3").trim()));
	    		p.setIssued(Integer.parseInt(req.getParameter("t4").trim()));
	    		boolean b=new MainClass().updateProductDetails(p);
				if(b)
				{
					RequestDispatcher rd=req.getRequestDispatcher("productsview");
					rd.forward(req, res);
				}
				else
				{
					out.print("failed");
				}
	    	}
	    	else if(path.equals("/deleteproducts"))
	    	{
	    		p.setPid(Integer.parseInt(req.getParameter("del").trim()));
	    		boolean b=new MainClass().deleteProduct(p.getPid());
	    		if(b)
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("productsview");
					rd.forward(req, res);
	    		}
	    		else
	    		{
	    			out.print("failed");
	    		}
	    	}
	    	else if(path.equals("/viewproductsbyid"))
	    	{
	    		p.setProductname(req.getParameter("t1"));
	    		ResultSet rs=new MainClass().getProductDetailsById(p.getProductname());
	    		out.print("<table border=1 cellpadding=7><tr bgcolor=yellow><td>pid</td><td>productname</td><td>quantity</td><td>issued</td></tr>");
	    	    try
	    	    {
	    		   while(rs.next())
	    		   {
	    			   out.print("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td></tr>");		
	    		   }
	    		}
	    	    catch(Exception e)
	    	    {
	    			System.out.println(e);
	    		}
	    	}
	    	else if(path.equals("/customerlogin"))
	    	{
	    		c.setUsername(req.getParameter("t1"));
	    		c.setPwd(req.getParameter("t2"));
	    		boolean b=new MainClass().customerLogin(c);
	    		if(b)
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("customerView.html");
	    			rd.forward(req, res);
	    		}
	    		else
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("customerLogin.html");
	    			rd.include(req, res);
	    			out.print("invalid user");
	    		}
	    	}
	    	else if(path.equals("/customerRegister"))
	    	{
	    		c.setFullname(req.getParameter("t1"));
	    	    c.setUsername(req.getParameter("t2"));
	    		c.setEmail(req.getParameter("t3"));
	    		c.setPwd(req.getParameter("t4"));
	    		boolean b=new MainClass().customerRegister(c);
	    		if(b)
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("customerRegister.html");
	    			rd.include(req, res);
	    			out.print("<body><center><h3>Registered sucessfully <a href=customerLogin.html>login</a></h3></center></body>");
	    		}
	    		else
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("customerRegister.html");
	    			rd.include(req, res);
	    			out.print("Registration failed");
	    		}
	    	}
	    	else if(path.equals("/customerpassword"))
	    	{
	    		c.setEmail(req.getParameter("t1"));
	    		c.setPwd(req.getParameter("t2"));
	    		boolean b=new MainClass().customerForgot(c);
	    		if(b)
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("customerForgot.html");
	    			rd.include(req, res);
	    			out.print("<body><center><h3>Password changed click here to login<a href=index.html>Login</a><h3></center></body>");
	    		}
	    		else
	    		{
	    			RequestDispatcher rd=req.getRequestDispatcher("customerForget.html");
	    			rd.forward(req, res);
	    			out.print("invalid email");
	    		}
	    	}
	    	else if(path.equals("/customerproducts"))
	    	{
	    		ArrayList<ProductModel> al=new ArrayList<ProductModel>();
	    		al=new MainClass().viewAllProducts();
	    		out.print("<table border=1 cellpadding=7><tr bgcolor=yellow><td>Product Name</td><td>Quantity</td><td>Add to cart</td></tr>");
	    		   for(ProductModel p1: al)
	    		   {
	    			   out.print("<tr><td>"+p1.getProductname()+"</td><td>"+p1.getQuantity()+"</td><td><a href=addtocart>Add to cart</a></td></tr>");		
	    		   }
	    	}
	    }
}
