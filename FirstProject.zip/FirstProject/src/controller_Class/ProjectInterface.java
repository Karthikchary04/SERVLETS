package controller_Class;

import java.sql.ResultSet;
import java.util.ArrayList;

import projectModel.CustomerModel;
import projectModel.Model;
import projectModel.ProductModel;

public interface ProjectInterface 
{     //Admin
	  public boolean login(Model m);
	  public boolean register(Model m);
	  public boolean forgot(Model m);
	  public boolean updateDetails(Model m);
	  public boolean delete(String fullname);
	  public ArrayList<Model> viewAll();
	  public Model viewDetailsById(String fullname);
	  //Products
	  public boolean addProduct(ProductModel p);
	  public boolean updateProductDetails(ProductModel p);
	  public boolean deleteProduct(int pid);
	  public ArrayList<ProductModel> viewAllProducts();
	  public ResultSet getProductDetailsById(String productname);
	  //customer
	  public boolean customerLogin(CustomerModel c);
	  public boolean customerRegister(CustomerModel c);
	  public boolean customerForgot(CustomerModel c);
	  public ResultSet viewProducts();//here i want to view products list and give link as add to cart 
	  //when i do this i want make product quantity less and issued increase and products name should be added in cart table
	 // in a single method.quantity should be change in product table in a single method can i do this
	  //sir im working on this today mrng only ive started ok sir yes sir
	    // ill modify resultset sir in view methods ok sir
	  //and sir how cart table shhould look sir like usename product1
	                                                // same username product2 or username pro1 pro2 pro3 ok sir thank you
	  //ok sir
}
