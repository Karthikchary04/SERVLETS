package controller_Class;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import controller_Class.MainClass;
import projectModel.CustomerModel;
import projectModel.Model;
import projectModel.ProductModel;

public class MainClass implements ProjectInterface
{
	static Connection con=null;
	public static Connection getConnectionObject()
	{
		try {
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","karthik","Karthik@04");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}
	public boolean login(Model m)
	{
		boolean b=false;
		ResultSet rs=null;
		con=MainClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select username,password from ptype3 where username='"+m.getUserName()+"' and password='"+m.getPassword()+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean forgot(Model m)
	{
		boolean b=false;
		int i=0;
		con=MainClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			i=st.executeUpdate("update ptype3 set password='"+m.getPassword()+"' where email='"+m.getEmail()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean register(Model m)
	{
		boolean b=false;
		int i=0;
		con=MainClass.getConnectionObject();
		try
		{
			PreparedStatement pst=con.prepareStatement("insert into ptype3 values(?,?,?,?)");
			pst.setString(1,m.getFullName());
			pst.setString(2,m.getUserName());
			pst.setString(3,m.getEmail());
			pst.setString(4,m.getPassword());
			i=pst.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<Model> viewAll() 
	{
		ResultSet rs=null;
		ArrayList<Model> al=new ArrayList<Model>(); 
		con=MainClass.getConnectionObject();
		try 
		{
			Statement stmt=con.createStatement();
			rs=stmt.executeQuery("select * from ptype3");
			while(rs.next())
			{
				Model m=new Model();
				m.setFullName(rs.getString(1));
				m.setUserName(rs.getString(2));
				m.setEmail(rs.getString(3));
				al.add(m);
			}
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
		return al;
	}
	public ResultSet update(Model m)
	{
		ResultSet rs=null;
		con=MainClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from ptype3 where fullname='"+m.getFullName()+"'");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return rs;
	}
	public boolean updateDetails(Model m)
	{
		boolean b=false;
		con=MainClass.getConnectionObject();
		int i=0;
		try
		{
			Statement st=con.createStatement();
			i=st.executeUpdate("update ptype3 set username='"+m.getUserName()+"',email='"+m.getEmail()+"' where fullname='"+m.getFullName()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean delete(String fullname)
	{
		boolean b=false;
		con=MainClass.getConnectionObject();
		int i=0;
		try
		{
			Statement st=con.createStatement();
			i=st.executeUpdate("delete from ptype3 where fullname='"+fullname+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public Model viewDetailsById(String fullname)
	{
		
		ResultSet rs=null;
		Model m=new Model();
		con=MainClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from ptype3 where fullname='"+fullname+"'");
			if(rs.next())
			{
				m.setFullName(rs.getString(1));
				m.setUserName(rs.getString(2));
				m.setEmail(rs.getString(3));
				m.setPassword(rs.getString(4));
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return m;
	}
	public boolean addProduct(ProductModel p) 
	{
		boolean b=false;
		int i=0;
		con=MainClass.getConnectionObject();
		try
		{
			PreparedStatement pst=con.prepareStatement("insert into products values(?,?,?,?)");
			pst.setInt(1,p.getPid());
			pst.setString(2,p.getProductname());
			pst.setInt(3,p.getQuantity());
			pst.setInt(4,p.getIssued());
			i=pst.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<ProductModel> viewAllProducts()
	{
		ArrayList<ProductModel> al=new ArrayList<ProductModel>();
		ResultSet rs=null;
		con=MainClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from products");
			while(rs.next())
			{
				ProductModel p=new ProductModel();
				p.setPid(Integer.parseInt(rs.getString(1)));
				p.setProductname(rs.getString(2));
				p.setQuantity(Integer.parseInt(rs.getString(3)));
				p.setIssued(Integer.parseInt(rs.getString(4)));
				al.add(p);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return al;
	}
	public ResultSet updateProducts(int pid)
	{
		ResultSet rs=null;
		con=MainClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from products where pid='"+pid+"'");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return rs;
	}
	public boolean updateProductDetails(ProductModel p) 
	{
		boolean b=false;
		con=MainClass.getConnectionObject();
		int i=0;
		try
		{
			Statement st=con.createStatement();
			i=st.executeUpdate("update products set productname='"+p.getProductname()+"',quantity='"+p.getQuantity()+"' where pid='"+p.getPid()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean deleteProduct(int pid) 
	{
		boolean b=false;
		con=MainClass.getConnectionObject();
		int i=0;
		try
		{
			Statement st=con.createStatement();
			i=st.executeUpdate("delete from products where pid='"+pid+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public ResultSet getProductDetailsById(String productname) 
	{
		ResultSet rs=null;
		con=MainClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from products where productname='"+productname+"'");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return rs;
	}
	public boolean customerLogin(CustomerModel c) 
	{
		boolean b=false;
		ResultSet rs=null;
		con=MainClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select username,password from customer where username='"+c.getUsername()+"' and password='"+c.getPwd()+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean customerRegister(CustomerModel c) 
	{
		boolean b=false;
		int i=0;
		con=MainClass.getConnectionObject();
		try
		{
			PreparedStatement pst=con.prepareStatement("insert into customer values(?,?,?,?)");
			pst.setString(1,c.getFullname());
			pst.setString(2,c.getUsername());
			pst.setString(3,c.getEmail());
			pst.setString(4,c.getPwd());
			i=pst.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public ResultSet viewProducts() 
	{
		ResultSet rs=null;
		con=MainClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select * from products");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return rs;
	}
	public boolean customerForgot(CustomerModel c) 
	{
		boolean b=false;
		int i=0;
		con=MainClass.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			i=st.executeUpdate("update customer set password='"+c.getPwd()+"' where email='"+c.getEmail()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
}
